
document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll(".fade-in");
  elements.forEach(el => {
    el.classList.add("visible");
  });
});
